<?php

namespace App\Controller;

use App\Repository\ArticleRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class ArticleController extends AbstractController
{
    #[Route('/article', name: 'article')]
    public function index(ArticleRepository $articles): Response
    {
        return $this->render('article/article.html.twig', [
            'controller_name' => 'ArticleController',
            'articles' => $articles->findBy(
                [],
                ['createdAt' => 'DESC']
            )
        ]);
    }

    // TODO : Réparer la route pour afficher un article en partant de son id
    #[Route('/article/{id}', name: 'show_article', methods:['GET', 'POST'])]
    public function show(ArticleRepository $article, $id): Response
    {
        return $this->render('article/show.html.twig', [
            'controller_name' => 'ArticleController',
            'article' => $article->findOneBy(
                ['id' => $id]
            )
        ]);
    }
}
